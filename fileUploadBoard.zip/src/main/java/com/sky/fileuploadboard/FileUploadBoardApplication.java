package com.sky.fileuploadboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadBoardApplication {

    public static void main(String[] args) {
        SpringApplication.run(FileUploadBoardApplication.class, args);
    }

}
