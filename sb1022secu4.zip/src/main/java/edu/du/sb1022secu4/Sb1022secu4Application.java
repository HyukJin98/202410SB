package edu.du.sb1022secu4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb1022secu4Application {

    public static void main(String[] args) {
        SpringApplication.run(Sb1022secu4Application.class, args);
    }

}
