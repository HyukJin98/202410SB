package edu.du.sb1022secu4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb1022Secu4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
